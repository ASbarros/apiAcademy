<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Academy;
use Illuminate\Http\Request;
use \Illuminate\Support\Str;

class AcademyController extends Controller
{
    private $Academy;
    private $API_TOKEN;

    function __construct(Academy $Academy)
    {
        $this->Academy = $Academy;
        $this->API_TOKEN = apache_request_headers()['ApiToken'];
    }

    public function index()
    {
        $Token = new TokenController();
        $a = strcmp($Token->getToken(apache_request_headers()['ApiEmail']), $this->API_TOKEN);
        if ($a != 0) return ['msg' => 'Usuário não autenticado!', 'color' => 'warning'];

        return ['result' => Academy::all()];
    }

    public function store(Request $request)
    {
        $Token = new TokenController();
        $a = strcmp($Token->getToken(apache_request_headers()['ApiEmail']), $this->API_TOKEN);
        if ($a != 0) return ['msg' => 'Usuário não autenticado!', 'color' => 'warning'];

        $this->Academy->cnpj = $request->cnpj;
        $this->Academy->name = $request->name;
        $this->Academy->nameFantasy = $request->nameFantasy;
        $this->Academy->save();
        return ["status" => 'ok'];
    }

    public function show($id)
    {
        $Token = new TokenController();
        $a = strcmp($Token->getToken(apache_request_headers()['ApiEmail']), $this->API_TOKEN);
        if ($a != 0) return ['msg' => 'Usuário não autenticado!', 'color' => 'warning'];

        return ['result' => $this->Academy->where('id', $id)->get()];
    }

    public function update(Request $request, $id)
    {
        $Token = new TokenController();
        $a = strcmp($Token->getToken(apache_request_headers()['ApiEmail']), $this->API_TOKEN);
        if ($a != 0) return ['msg' => 'Usuário não autenticado!', 'color' => 'warning'];

        $data = $request->all();
        if (!$data['name']) return ['msg' => 'Nova razão social não pode ser vazia', 'color' => 'warning'];
        if (!$data['nameFantasy']) return ['msg' => 'Novo nome não pode ser vazio', 'color' => 'warning'];

        $this->Academy = Academy::findOrFail($id);
        $this->Academy->name = $data['name'];
        $this->Academy->cnpj = $data['cnpj'];
        $this->Academy->nameFantasy = $data['nameFantasy'];

        $this->Academy->save();
        return ['msg' => 'Atualizado com sucesso', 'color' => 'success'];
    }

    public function destroy($id)
    {
        $Token = new TokenController();
        $a = strcmp($Token->getToken(apache_request_headers()['ApiEmail']), $this->API_TOKEN);
        if ($a != 0) return ['msg' => 'Usuário não autenticado!', 'color' => 'warning'];
        
        $this->Academy = Academy::findOrFail($id);
        try {
            $this->Academy->delete();
        } catch (\Throwable $th) {
            return ['msg' => 'Registro não apagado, possui dependêcias', 'color' => 'warning'];
        }
        return ['msg' => 'Apagado com sucesso', 'color' => 'success'];
    }
}
