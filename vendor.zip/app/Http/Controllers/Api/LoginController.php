<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\User;
use Illuminate\Http\Request;

class LoginController extends Controller
{
    public function index(Request $request)
    {
        $Users =  User::where('email', '=', $request->email)
            ->where('pswd', '=', $request->pswd)
            ->get();
        $User = false;
        $Response = [];
        $Token = new TokenController();

        foreach ($Users as $UserCurrent) {
            $User = $UserCurrent;
        }

        if ($User) {
            header('ApiToken: ' . $Token->getToken($User->email));
            $Response['msg'] = 'success';
            $Response['ApiToken'] = $Token->getToken($User->email);
            $Response['success'] = true;
            return $Response;
        }

        $Response['status'] = true;
        return $Response;
    }
}
