<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Group;
use Illuminate\Http\Request;

class GroupController extends Controller
{
    private $Group;
    private $API_TOKEN;

    function __construct(Group $Group)
    {
        $this->Group = $Group;
        $this->API_TOKEN = apache_request_headers()['ApiToken'];
        $Token = new TokenController();
        if(!$Token->getToken(apache_request_headers()['ApiEmail']) == $this->API_TOKEN){
            return;
        }
    }

    public function index()
    {
        $Token = new TokenController();
        $a = strcmp($Token->getToken(apache_request_headers()['ApiEmail']), $this->API_TOKEN);
        if ($a != 0) return ['msg' => 'Usuário não autenticado!', 'color' => 'warning'];

        return ['result' => Group::all()];
    }

    public function store(Request $request)
    {
        $Token = new TokenController();
        $a = strcmp($Token->getToken(apache_request_headers()['ApiEmail']), $this->API_TOKEN);
        if ($a != 0) return ['msg' => 'Usuário não autenticado!', 'color' => 'warning'];

        $Group = new Group();
        
        if (!$request->desc) return ['color' => 'warning', 'msg' => 'Digite o nome do grupo'];

        $Group->desc = $request->desc;

        if ($request->obs) $Group->obs = $request->obs;
        else $Group->obs = '';

        $Group->save();

        return ['color' => 'success', 'msg' => 'Criado com sucesso'];
    }

    public function show($id)
    {
        $Token = new TokenController();
        $a = strcmp($Token->getToken(apache_request_headers()['ApiEmail']), $this->API_TOKEN);
        if ($a != 0) return ['msg' => 'Usuário não autenticado!', 'color' => 'warning'];

        return ['result' => Group::where('id', $id)->get()];
    }

    public function update(Request $request, $id)
    {
        $Token = new TokenController();
        $a = strcmp($Token->getToken(apache_request_headers()['ApiEmail']), $this->API_TOKEN);
        if ($a != 0) return ['msg' => 'Usuário não autenticado!', 'color' => 'warning'];

        $Group = Group::findOrFail($id);

        if (!$request->desc) return ['color' => 'warning', 'msg' => 'Novo nome não pode ser vazio!'];

        $Group->desc = $request->desc;

        if ($request->obs) $Group->obs = $request->obs;
        else $Group->obs = '';

        $Group->save();

        return ['color' => 'success', 'msg' => 'Atualizado com sucesso', 'result' => $request->all()];
    }

    public function destroy($id)
    {
        $Token = new TokenController();
        $a = strcmp($Token->getToken(apache_request_headers()['ApiEmail']), $this->API_TOKEN);
        if ($a != 0) return ['msg' => 'Usuário não autenticado!', 'color' => 'warning'];
        
        $Group = Group::findOrFail($id);
        $Group->delete();
        return ['msg' => 'Apagado com sucesso', 'color' => 'success'];
    }
}
