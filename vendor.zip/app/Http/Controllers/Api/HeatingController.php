<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Heating;
use Illuminate\Http\Request;

class HeatingController extends Controller
{

    private $Heating;
    private $API_TOKEN;

    function __construct(Heating $Heating)
    {
        $this->Heating = $Heating;
        $this->API_TOKEN = apache_request_headers()['ApiToken'];
    }

    public function index()
    {
        $Token = new TokenController();
        $a = strcmp($Token->getToken(apache_request_headers()['ApiEmail']), $this->API_TOKEN);
        if ($a != 0) return ['msg' => 'Usuário não autenticado!', 'color' => 'warning'];

        return ['result' => Heating::all()];
    }

    public function store(Request $request)
    {
        $Token = new TokenController();
        $a = strcmp($Token->getToken(apache_request_headers()['ApiEmail']), $this->API_TOKEN);
        if ($a != 0) return ['msg' => 'Usuário não autenticado!', 'color' => 'warning'];

        $Heating = new Heating();
        $Heating->desc = $request->desc;
        $Heating->save();
        return ['color' => 'success', 'msg' => 'Criado com sucesso'];
    }

    public function show($id)
    {
        $Token = new TokenController();
        $a = strcmp($Token->getToken(apache_request_headers()['ApiEmail']), $this->API_TOKEN);
        if ($a != 0) return ['msg' => 'Usuário não autenticado!', 'color' => 'warning'];

        return ['result' => Heating::where('id', $id)->get()];
    }
   
    public function update(Request $request, $id)
    {
        $Token = new TokenController();
        $a = strcmp($Token->getToken(apache_request_headers()['ApiEmail']), $this->API_TOKEN);
        if ($a != 0) return ['msg' => 'Usuário não autenticado!', 'color' => 'warning'];

        $Heating = Heating::findOrFail($id);
        $Heating->desc = $request->desc;
        $Heating->save();
        return ['color' => 'success', 'msg' => 'Atualizado com sucesso'];
    }

    public function destroy($id)
    {
        $Token = new TokenController();
        $a = strcmp($Token->getToken(apache_request_headers()['ApiEmail']), $this->API_TOKEN);
        if ($a != 0) return ['msg' => 'Usuário não autenticado!', 'color' => 'warning'];
        
        $Heating = Heating::findOrFail($id);
        $Heating->delete();
        return ['msg' => 'Apagado com sucesso', 'color' => 'success'];
    }
}
