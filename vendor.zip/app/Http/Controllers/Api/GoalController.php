<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Goal;
use Illuminate\Http\Request;

class GoalController extends Controller
{
    private $API_TOKEN;
    private $Goal;

    function __construct(Goal $Goal)
    {
        $Token = new TokenController();
        $a = strcmp($Token->getToken(apache_request_headers()['ApiEmail']), $this->API_TOKEN);
        if ($a != 0) return ['msg' => 'Usuário não autenticado!', 'color' => 'warning'];

        $this->Goal = $Goal;
        $this->API_TOKEN = apache_request_headers()['ApiToken'];
        $Token = new TokenController();
        if(!$Token->getToken(apache_request_headers()['ApiEmail']) == $this->API_TOKEN){
            return;
        }
    }
    public function index()
    {
        $Token = new TokenController();
        $a = strcmp($Token->getToken(apache_request_headers()['ApiEmail']), $this->API_TOKEN);
        if ($a != 0) return ['msg' => 'Usuário não autenticado!', 'color' => 'warning'];

        return ['result' => Goal::all()];
    }

    public function store(Request $request)
    {
        $Token = new TokenController();
        $a = strcmp($Token->getToken(apache_request_headers()['ApiEmail']), $this->API_TOKEN);
        if ($a != 0) return ['msg' => 'Usuário não autenticado!', 'color' => 'warning'];

        $Goal = new Goal();
        $Goal->desc = $request->desc;
        $Goal->save();
        return ['color' => 'success', 'msg' => 'Criado com sucesso'];
    }

    public function show($id)
    {
        $Token = new TokenController();
        $a = strcmp($Token->getToken(apache_request_headers()['ApiEmail']), $this->API_TOKEN);
        if ($a != 0) return ['msg' => 'Usuário não autenticado!', 'color' => 'warning'];

        return ['result' => Goal::where('id', $id)->get()];
    }

    public function update(Request $request, $id)
    {
        $Token = new TokenController();
        $a = strcmp($Token->getToken(apache_request_headers()['ApiEmail']), $this->API_TOKEN);
        if ($a != 0) return ['msg' => 'Usuário não autenticado!', 'color' => 'warning'];

        $Goal = Goal::findOrFail($id);
        $Goal->desc = $request->desc;
        $Goal->save();
        return ['color' => 'success', 'msg' => 'Atualizado com sucesso'];
    }

    public function destroy($id)
    {
        $Token = new TokenController();
        $a = strcmp($Token->getToken(apache_request_headers()['ApiEmail']), $this->API_TOKEN);
        if ($a != 0) return ['msg' => 'Usuário não autenticado!', 'color' => 'warning'];
        
        $Goal = Goal::findOrFail($id);
        $Goal->delete();
        return ['msg' => 'Apagado com sucesso', 'color' => 'success'];
    }
}
