<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Equipament;
use Illuminate\Http\Request;

class EquipamentController extends Controller
{
    private $API_TOKEN;
    
    public function index()
    {
        $Token = new TokenController();
        $a = strcmp($Token->getToken(apache_request_headers()['ApiEmail']), $this->API_TOKEN);
        if ($a != 0) return ['msg' => 'Usuário não autenticado!', 'color' => 'warning'];

        return ['result' => Equipament::all()];
        $this->API_TOKEN = apache_request_headers()['ApiToken'];
        $Token = new TokenController();
        if (!$Token->getToken(apache_request_headers()['ApiEmail']) == $this->API_TOKEN) {
            return;
        }
    }

    public function store(Request $request)
    {
        $Token = new TokenController();
        $a = strcmp($Token->getToken(apache_request_headers()['ApiEmail']), $this->API_TOKEN);
        if ($a != 0) return ['msg' => 'Usuário não autenticado!', 'color' => 'warning'];

        if (!$request->name) return ['color' => 'danger', 'msg' => 'Campo nome é obrigatório'];
        $Equipament = new Equipament();
        $Equipament->name = $request->name;
        if ($request->obs)
            $Equipament->obs = $request->obs;
        else $Equipament->obs = '';
        $Equipament->save();
        return ['color' => 'success', 'msg' => 'Criado com sucesso'];
    }

    public function show($id)
    {
        $Token = new TokenController();
        $a = strcmp($Token->getToken(apache_request_headers()['ApiEmail']), $this->API_TOKEN);
        if ($a != 0) return ['msg' => 'Usuário não autenticado!', 'color' => 'warning'];

        return ['result' => Equipament::where('id', $id)->get()];
    }

    public function update(Request $request, $id)
    {
        $Token = new TokenController();
        $a = strcmp($Token->getToken(apache_request_headers()['ApiEmail']), $this->API_TOKEN);
        if ($a != 0) return ['msg' => 'Usuário não autenticado!', 'color' => 'warning'];

        if (!$request->name) return ['msg' => 'Novo nome não pode ser vazio', 'color' => 'warning'];

        $Equipament = Equipament::findOrFail($id);
        $Equipament->name = $request->name;

        if ($request->obs) $Equipament->obs = $request->obs;
        else $Equipament->obs = '';

        $Equipament->save();
        return ['msg' => 'Atualizado com sucesso', 'color' => 'success'];
    }

    public function destroy($id)
    {
        $Token = new TokenController();
        $a = strcmp($Token->getToken(apache_request_headers()['ApiEmail']), $this->API_TOKEN);
        if ($a != 0) return ['msg' => 'Usuário não autenticado!', 'color' => 'warning'];
        
        $Equipament = Equipament::findOrFail($id);
        $Equipament->delete();
        return ['msg' => 'Apagado com sucesso', 'color' => 'success'];
    }
}
