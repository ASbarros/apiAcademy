<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\UsersGroups;
use Illuminate\Http\Request;

class UsersGroupsController extends Controller
{
    private $UserGroup;
    private $API_TOKEN;

    function __construct(UsersGroups $usersGroups)
    {
        $this->UserGroup = $usersGroups;
        $this->API_TOKEN = apache_request_headers()['ApiToken'];
        $Token = new TokenController();
        if (!$Token->getToken(apache_request_headers()['ApiEmail']) == $this->API_TOKEN) {
            return;
        }
    }

    public function index()
    {
        $Token = new TokenController();
        $a = strcmp($Token->getToken(apache_request_headers()['ApiEmail']), $this->API_TOKEN);
        if ($a != 0) return ['msg' => 'Usuário não autenticado!', 'color' => 'warning'];

        return UsersGroups::all();
    }

    public function store(Request $request)
    {
        $Token = new TokenController();
        $a = strcmp($Token->getToken(apache_request_headers()['ApiEmail']), $this->API_TOKEN);
        if ($a != 0) return ['msg' => 'Usuário não autenticado!', 'color' => 'warning'];

        $this->UserGroup->pswdUsers = $request->pswd;
        $this->UserGroup->idGroups = $request->idgroups;
        $this->UserGroup->idUsers = $request->idusers;
        $this->UserGroup->save();
        return ['status' => 'success'];
    }

    public function show($id)
    {
        $Token = new TokenController();
        $a = strcmp($Token->getToken(apache_request_headers()['ApiEmail']), $this->API_TOKEN);
        if ($a != 0) return ['msg' => 'Usuário não autenticado!', 'color' => 'warning'];

        return ['msg' => 'funcao nao implementada'];
    }

    public function update(Request $request, $id)
    {
        $Token = new TokenController();
        $a = strcmp($Token->getToken(apache_request_headers()['ApiEmail']), $this->API_TOKEN);
        if ($a != 0) return ['msg' => 'Usuário não autenticado!', 'color' => 'warning'];

        return ['msg' => 'funcao nao implementada'];
    }

    public function destroy($id)
    {
        $Token = new TokenController();
        $a = strcmp($Token->getToken(apache_request_headers()['ApiEmail']), $this->API_TOKEN);
        if ($a != 0) return ['msg' => 'Usuário não autenticado!', 'color' => 'warning'];

        return ['msg' => 'funcao nao implementada'];
    }
}
