<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Academy;
use App\Models\Group;
use App\Models\User;
use App\Models\UsersGroups;
use Illuminate\Http\Request;

class UserController extends Controller
{
    private $User;
    private $API_TOKEN;

    function __construct(User $User)
    {
        $this->User = $User;
        $this->API_TOKEN = apache_request_headers()['ApiToken'];
        $Token = new TokenController();
        if(!$Token->getToken(apache_request_headers()['ApiEmail']) == $this->API_TOKEN){
            return;
        }
    }

    public function index()
    {
        $Token = new TokenController();
        $a = strcmp($Token->getToken(apache_request_headers()['ApiEmail']), $this->API_TOKEN);
        if ($a != 0) return ['msg' => 'Usuário não autenticado!', 'color' => 'warning'];

        return ['result' => $this->User->all()];
    }

    public function store(Request $request)
    {
        $Token = new TokenController();
        $a = strcmp($Token->getToken(apache_request_headers()['ApiEmail']), $this->API_TOKEN);
        if ($a != 0) return ['msg' => 'Usuário não autenticado!', 'color' => 'warning'];

        $data = $request->all();

        $this->User->validationFileds($data);

        $this->User->active = $data->active ? 1 : 0;
        $this->User->pswd = $data->cpf;
        $this->User->name = $data->name;
        //$User->idAcademy = $request->idAcademy;
        $this->User->idAcademy = 1;
        $this->User->email = $data->email;
        $this->User->cpf = $data->cpf;

        $this->User->save();
        return ['color' => 'success', 'msg' => 'Criado com sucesso'];
        // refatorar conforme a pagina 122 do pdf
    }

    public function create()
    {
        $Token = new TokenController();
        $a = strcmp($Token->getToken(apache_request_headers()['ApiEmail']), $this->API_TOKEN);
        if ($a != 0) return ['msg' => 'Usuário não autenticado!', 'color' => 'warning'];

        $Retorno = [];
        $Retorno['result'][0]['groups'] = Group::all();
        $Retorno['result'][0]['academys'] = Academy::all();
        return $Retorno;
    }

    public function show($id)
    {
        $Token = new TokenController();
        $a = strcmp($Token->getToken(apache_request_headers()['ApiEmail']), $this->API_TOKEN);
        if ($a != 0) return ['msg' => 'Usuário não autenticado!', 'color' => 'warning'];

        $Resultado = [];
        $Groups = UsersGroups::where('idUsers', $id)->get();
        $Resultado['groups'] = [];
        foreach ($Groups as $i => $Group) {
            $Resultado['groups'][$i] = Group::findOrFail($Group->idGroups);
        }
        $User = User::findOrFail($id);
        $Resultado['user'] = $User;
        $Resultado['academy'] = Academy::where('id', $User->idAcademy)->get('name');
        return ['result' => [$Resultado]];
    }

    public function update(Request $request, $id)
    {
        $Token = new TokenController();
        $a = strcmp($Token->getToken(apache_request_headers()['ApiEmail']), $this->API_TOKEN);
        if ($a != 0) return ['msg' => 'Usuário não autenticado!', 'color' => 'warning'];

        $data = $request->all();
        $User = User::findOrFail($id);
        if (!$this->User->validationFileds($data)[0])
            $this->User->validationFileds($data)[1];
        $User->active = $data['active'] ? 1 : 0;
        $User->pswd = $data['cpf'];
        $User->name = $data['name'];
        $User->idAcademy = $data['academy'];
        $User->email = $data['email'];
        $User->cpf = $data['cpf'];

        // update users_groups ...
        $ArrayGroups = $data['group'];
        $User->save();
        $User->getGroups()->sync($ArrayGroups);

        return ['msg' => 'Atualizado com sucesso', 'color' => 'success'];
    }

    public function destroy($id)
    {
        $Token = new TokenController();
        $a = strcmp($Token->getToken(apache_request_headers()['ApiEmail']), $this->API_TOKEN);
        if ($a != 0) return ['msg' => 'Usuário não autenticado!', 'color' => 'warning'];
        
        $User = User::findOrFail($id);
        $User->delete();
        return ['msg' => 'Apagado com sucesso', 'color' => 'success'];
    }
}
