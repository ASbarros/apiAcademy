<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\CardEquipament;
use Illuminate\Http\Request;

class CardEquipamentController extends Controller
{
    private $CardEquipament;
    private $Resultado;
    private $API_TOKEN;

    function __construct(CardEquipament $CardEquipament)
    {
        $this->CardEquipament = $CardEquipament;
        $this->Resultado = [];
        $this->API_TOKEN = apache_request_headers()['ApiToken'];
        $Token = new TokenController();
        if(!$Token->getToken(apache_request_headers()['ApiEmail']) == $this->API_TOKEN){
            return;
        }
    }

    public function index()
    {
        $Token = new TokenController();
        $a = strcmp($Token->getToken(apache_request_headers()['ApiEmail']), $this->API_TOKEN);
        if ($a != 0) return ['msg' => 'Usuário não autenticado!', 'color' => 'warning'];

        return ['result' => $this->CardEquipament->all()];
    }

    public function store(Request $request)
    {
        $Token = new TokenController();
        $a = strcmp($Token->getToken(apache_request_headers()['ApiEmail']), $this->API_TOKEN);
        if ($a != 0) return ['msg' => 'Usuário não autenticado!', 'color' => 'warning'];

        $data = $request->all();
        try {
            $this->CardEquipament->idEquipaments = $data['idEquipaments'];
            $this->CardEquipament->rest = $data['rest'];
            $this->CardEquipament->repetition = $data['repetition'];
            $this->CardEquipament->series = $data['series'];
            $this->CardEquipament->weight = $data['weight'];
            $this->CardEquipament->side = $data['side'];
            $this->CardEquipament->idCard = $data['idCard'];
        } catch (\Throwable $th) {
            return ['msg' => 'Erro nos dados.', 'color' => 'warning'];
        }
        try {
            $this->CardEquipament->save();
        } catch (\Throwable $th) {
            return ['msg' => 'Registro já existe', 'color' => 'warning'];
        }
        return ['msg' => 'Criado com sucesso', 'color' => 'success'];
    }


    public function show($idCard, $idEquipament)
    {
        $Token = new TokenController();
        $a = strcmp($Token->getToken(apache_request_headers()['ApiEmail']), $this->API_TOKEN);
        if ($a != 0) return ['msg' => 'Usuário não autenticado!', 'color' => 'warning'];

        $CardEquipaments = CardEquipament::where('idCard', $idCard)->get();

        foreach ($CardEquipaments as $a) {
            $equipament = $a->getEquipaments;
            if ($equipament->id == $idEquipament) $this->Resultado['equipament'] = $equipament;
        }

        $this->Resultado['data'] = CardEquipament::where([
            ['idCard', $idCard],
            ['idEquipaments', $idEquipament]
        ])->get();

        return ['result' => [$this->Resultado]];
    }

    public function update(Request $request, $idCard, $idEquipament)
    {
        $Token = new TokenController();
        $a = strcmp($Token->getToken(apache_request_headers()['ApiEmail']), $this->API_TOKEN);
        if ($a != 0) return ['msg' => 'Usuário não autenticado!', 'color' => 'warning'];

        $data = $request->all();
        $this->CardEquipament = CardEquipament::where([
            ['idCard', $idCard],
            ['idEquipaments', $idEquipament]
        ]);

        $this->CardEquipament->update(
            ['rest' => $data['rest']]
        );
        $this->CardEquipament->update(
            ['repetition' => $data['repetition']]
        );
        $this->CardEquipament->update(
            ['weight' => $data['weight']]
        );
        $this->CardEquipament->update(
            ['side' => $data['side']]
        );

        return ['msg' => 'Atualizado com sucesso', 'color' => 'success'];
    }

    public function destroy($idCard, $idEquipament)
    {
        $Token = new TokenController();
        $a = strcmp($Token->getToken(apache_request_headers()['ApiEmail']), $this->API_TOKEN);
        if ($a != 0) return ['msg' => 'Usuário não autenticado!', 'color' => 'warning'];
        
        $this->CardEquipament = CardEquipament::where([
            ['idCard', $idCard],
            ['idEquipaments', $idEquipament]
        ])->delete();

        return ['msg' => 'Apagado com sucesso', 'color' => 'success'];
    }
}
